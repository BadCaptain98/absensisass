<?php ?>
<!-- Begin Page Content -->
        <div class="container-fluid">

          <div class="alert alert-info alert-dismissible fade show" role="alert">
            Hubungi Developer Via E-Mail <code>lukmanha73@gmail.com</code> Untuk Versi Lengkap ☺
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->